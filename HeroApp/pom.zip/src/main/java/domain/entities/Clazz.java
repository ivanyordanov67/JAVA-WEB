package domain.entities;

public enum  Clazz {

    warrior, archer, mage,
}

