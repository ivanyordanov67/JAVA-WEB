package web;

import domain.models.view.HomeViewModel;
import org.modelmapper.ModelMapper;
import services.HeroService;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

@Named
@RequestScoped
public class DetailsHeroBean extends BaseBean {

    private HomeViewModel model;
    private HeroService heroService;
    private ModelMapper modelMapper;

    public DetailsHeroBean() {
    }

    @Inject
    public DetailsHeroBean(HeroService heroService, ModelMapper modelMapper) {
        this.heroService = heroService;
        this.modelMapper = modelMapper;
    }

    public HomeViewModel getById(String id){
        return this.modelMapper.map(this.heroService.getById(id), HomeViewModel.class);
    }

    public HomeViewModel getModel() {
        return model;
    }

    public void setModel(HomeViewModel model) {
        this.model = model;
    }
}
