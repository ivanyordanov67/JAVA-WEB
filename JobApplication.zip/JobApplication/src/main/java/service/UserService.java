package service;

import domain.models.services.UserServiceModel;

public interface UserService {

    void save(UserServiceModel user);
}
